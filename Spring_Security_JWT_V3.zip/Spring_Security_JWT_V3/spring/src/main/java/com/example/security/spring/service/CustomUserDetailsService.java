package com.example.security.spring.service;

import org.springframework.beans.factory.annotation.Autowired;

//import com.jwt.model.CustomUserDetails;
//import com.jwt.model.User;
//import com.jwt.repo.UserRepository;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.security.spring.model.UserEntity;
import com.example.security.spring.repo.UserRepository;

import java.util.ArrayList;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

        UserEntity user = userRepository.findByMail(userName);
//
//        if (user == null) {
//            throw new UsernameNotFoundException("User not found !!");
//        } else {
//            return new CustomUserDetails(user);
//        }


//        user database `

    	if (userName.equals(user.getMail())) {
            return new  User(user.getMail(), user.getPassword(), new ArrayList<>());
        } 
//    	else if (userName.equals("user")) {
//            return new  User("user", "virat", new ArrayList<>());
//        }else if (userName.equals("sunil")) {
//            return new  User("sunil", "123", new ArrayList<>());
//        }
        else 
        {
            throw new UsernameNotFoundException("User not found !!");
        }

    }
}
