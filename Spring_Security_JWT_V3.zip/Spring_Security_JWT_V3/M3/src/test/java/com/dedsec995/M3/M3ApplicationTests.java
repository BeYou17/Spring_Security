package com.dedsec995.M3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
