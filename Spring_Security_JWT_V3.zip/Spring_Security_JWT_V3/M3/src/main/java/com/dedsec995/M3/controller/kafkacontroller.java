package com.dedsec995.M3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
//import com.dedsec995.M3.service.Pro;

import com.datastax.oss.driver.api.core.servererrors.InvalidQueryException;
import com.dedsec995.M3.model.UserModel;
import com.dedsec995.M3.model.Vinspeed;
import com.dedsec995.M3.repository.UserRepository;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@CrossOrigin
public class kafkacontroller {
	
//	@Autowired
//	Pro pro;

	@Autowired
	private UserRepository repository;
	
//	@PostMapping(value="/post")
//	public void sendMessage(@RequestParam("msg") String msg) {
//		pro.publishToTopic(msg);
//	}
//	@GetMapping("/getAllUsers")
//    public List<User> getUsers() {
//        return repository.findAll();
//    }
//	@PostMapping("/test")
//    public void postBody(@RequestBody String fullName) {
//        System.out.println(fullName); 
//    }
	@RequestMapping(value="/vinspeed", method=RequestMethod.POST)
	public ResponseEntity<Object> create(@RequestBody Vinspeed vinspeed) throws Exception {
//		System.out.println(vinspeed.getVinspeed());
		consumerFromtopic(vinspeed.getVinspeed());
		return new ResponseEntity<Object>("created" + vinspeed.getVinspeed(),HttpStatus.CREATED);
	
	}
	public void consumerFromtopic(String message) throws Exception {
		System.out.println("consumer" + message);
		String msg = message.substring(22);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = df.parse(msg);
        long time = date.getTime();
		String[] emailIds = new String[4];
		emailIds[0] = "beyouabde@gmail.com";
		emailIds[1] = "sunilindi@tataelxsi.co.in";
		emailIds[2] = "sunilindi0@gmail.com";
		emailIds[3] = "itachu.uchiha99@gmail.com";

        Timestamp ts = new Timestamp(time);
		int speed = Integer.parseInt(message.substring(18, 21));
		// User users=new User(message.substring(0, 17),message.substring(17,18),speed,message.substring(21, 22),ts);
		// repository.save(users);
//		System.out.println("Done Writing");
		
		String s1=message.substring(21, 22);
		String s2="y";
		
		try {
		UserModel users = new UserModel(message.substring(0, 17),message.substring(17,18),speed,message.substring(21, 22),ts);
		repository.save(users);
		System.out.println("Done Writing");
		
		
//		if(s1.equals(s2) && message.substring(17,18).equals(s2)) {
//
//	
//		
//			this.emailSenderService.sendHTML(emailIds,"sunilindi0@gamil.com", "Warning!! You have Crossed the Speed", "<h2>ALERT...!!!<h2>"+"<p>Dear user you have crossed the speed limits, your vehicle is running with overspeed <br/>The Safe Speed limit was 100 km/h.<p>"+"<h2>Details: </h2>"+"<h2>Your Vin:"+message.substring(0, 17)+" </h2>"+"<h2>Speed:"+speed+" km/h</h2>"+"<h2>Date and Time:"+ts+" </h2>");
//			System.out.println("mail sent....");
//		}
		
		}
		catch (InvalidQueryException e) {
			System.out.println("Exception 1");
		}
		catch (DataAccessException ex) {
			System.out.println("Exception Occured mail not sent!!!");
		}
	


		
	}
}