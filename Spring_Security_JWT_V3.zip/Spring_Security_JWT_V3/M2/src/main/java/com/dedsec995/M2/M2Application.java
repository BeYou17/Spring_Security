package com.dedsec995.M2;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.dedsec995.M2.model.Vinspeed;

@SpringBootApplication
@EnableDiscoveryClient
@EnableEurekaClient
public class M2Application {

	public static void main(String[] args) {
		SpringApplication.run(M2Application.class, args);
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
		
	}

//@Autowired
//RestTemplate restTemplate;
//	
//public String create(Vinspeed vinspeed) {
////  MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>(createHeaders("sunil", "123"));
////  MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>();
////body.add("sunil", "pass");
////  System.out.println(body);
////  System.out.println(createHeaders("dsaugi", "kmlcnpasqwds"));
//	HttpHeaders headers=new HttpHeaders();
//
//	   headers.set("Authorization", "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzdW5pbCIsImV4cCI6MTY0MDM4NTIzNCwiaWF0IjoxNjQwMzY3MjM0fQ.I4YnjVtqgZBlpIRn1zcjM4qZv1fAUKfasKw1TvU3lY3Cz8Ud-X-N3OfZ0sPn2kctpXavkXb13ZPOjgovQJPzAg");
////	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
////	HttpEntity<Vinspeed> entity=new HttpEntity<Vinspeed>(vinspeed,createHeaders("sunil", "pass"));
//HttpEntity<Vinspeed> entity=new HttpEntity<Vinspeed>(vinspeed,headers);
//	ResponseEntity<String> response=restTemplate.exchange("http://localhost:8882/vinspeed",HttpMethod.POST,entity,String.class);
//	System.out.println(response.getBody());
////	if(response.getStatusCodeValue()==201) {
////		System.out.println("Succes");
////		
////	}
//  return response.getBody();
//	
//}

}
