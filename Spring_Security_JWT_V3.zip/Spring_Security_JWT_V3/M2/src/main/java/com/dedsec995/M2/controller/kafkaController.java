package com.dedsec995.M2.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
//import com.dedsec995.M2.service.Producer;
import org.springframework.web.util.UriComponentsBuilder;

import com.dedsec995.M2.M2Application;
//import com.dedsec995.M2.model.Vinspeed;//import com.dedsec995.M2.service.Consumer;
import com.dedsec995.M2.model.Vinspeed;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


@RestController
@CrossOrigin
//@RequestMapping("/my")
public class kafkaController {
	
//	@Autowired 
//	Vinspeed vin;
//	Consumer consumer;
//	Producer producer;
	@Autowired 
	M2Application m1;
	
	@Autowired
	RestTemplate restTemplate;

//	@Autowired
//	Vinspeed vin;'
	
//	
	public static String token;
	

	
//	@RequestHeader(name="X_COM_PERSIST",required=true) String headerPersist, @RequestHeader(name="X_COM_LOCATION",defaultValue="USA") String headerLocation,
	 
//	@RequestMapping(value="/vinspeed", method = RequestMethod.POST, produces = {"application/json","application/xml"}, consumes = {"application/json","application/xml"})
	 //,UriComponentsBuilder builder
//	 public ResponseEntity<String> create( @RequestBody Vinspeed vinspeed  )  {
	
	
	  public void token(String tkn) {
		   System.out.println(tkn);
		   token=tkn;
	   }
	  
	   public String auth() {
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>(createHeaders("sunil", "123"));
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>();
		//body.add("username","sunil");
		//body.add("password","abde");

		String payload="{\"username\":\"sunil\",\"password\":\"abde\"}";
       

		//body.add("sunil","abde");
//		    System.out.println(body);
//		    System.out.println(createHeaders("dsaugi", "kmlcnpasqwds"));
			HttpHeaders headers=new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);


//			   headers.set("Authorization", "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzdW5pbCIsImV4cCI6MTY0MDM4NTgyMiwiaWF0IjoxNjQwMzY3ODIyfQ.6GdzTALoIbU2BySPiU9nO6ZfD3CKosFHNq9k5o3cBzZ61IPrs6p5U9VTFdacNq4Sm3hajIPkhhxtmb2rCnpznA");
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<String> entity=new HttpEntity<String>(payload,headers);
		// HttpEntity<MultiValueMap<String,String>> entity=new HttpEntity<MultiValueMap<String,String>>(body,headers);
			ResponseEntity<String> response=restTemplate.exchange("http://localhost:8882/token",HttpMethod.POST,entity,String.class);
//			System.out.println(response.getBody());
//			if(response.getStatusCodeValue()==201) {
//				System.out.println("Succes");
			if(response!=null && response.getStatusCode().equals(HttpStatus.OK)) {

//			   response.getBody().valueOf(token);
			
              token=response.getBody();
				 System.out.println(response.getBody());
				return "SUCCESS!";
			}
//				
//			}
		    return "wrong credentials";
			
		}
	  
	   public String create(Vinspeed vinspeed) {
		   
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>(createHeaders("sunil", "123"));
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>();
		// body.add("sunil", "pass");
//		    System.out.println(body);
//		    System.out.println(createHeaders("dsaugi", "kmlcnpasqwds"));
			 HttpHeaders headers=new HttpHeaders();
		     headers.set("Authorization", "Bearer "+token);
//			 System.out.println(token);
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//			HttpEntity<Vinspeed> entity=new HttpEntity<Vinspeed>(vinspeed,createHeaders("sunil", "pass"));
		  HttpEntity<Vinspeed> entity1=new HttpEntity<Vinspeed>(vinspeed,headers);
			ResponseEntity<String> response1=restTemplate.exchange("http://M3-SERVICE/vinspeed",HttpMethod.POST,entity1,String.class);
//			System.out.println(response.getBody());
//			if(response.getStatusCodeValue()==201) {
//				System.out.println("Succes");
//				
//			}
		    return response1.getBody();
			
		}
	
	
	
	 @RequestMapping(value="/vinspeed",method = RequestMethod.POST) 
	public ResponseEntity<Object> create( @RequestBody Vinspeed vinspeed , @RequestHeader MultiValueMap<String, String> headers)  {
		
		consumeFromTopic(vinspeed.getVinspeed());
		 return new ResponseEntity<Object>(
			      String.format("Listed %d headers", headers.size()), HttpStatus.OK);
//		return new ResponseEntity<String>("created " + vinspeed.getVinspeed(),HttpStatus.CREATED);
		
	
	}
    
	public int consumeFromTopic(String message) {

        System.out.println("Consummed message  "+message);

        String msg=message.substring(0, 20);
        String dateTime=message.substring(20);
        
        int speed1 = Integer.parseInt(message.substring(17, 20));
        if(msg.length() != 20 || speed1<0) {
	    	return 0;
	    }
	    
	    String vin = msg.substring(0,17);
 	    String speed = msg.substring(17,20);
 	    boolean isvinaalphaNumeric;
        boolean isvinnNumeric;
 	    boolean isNumeric;
        char verify = 'n';
        char alert = 'n';
		String vina = vin.substring(0,10);
        String vinn = vin.substring(11,16);
		isvinaalphaNumeric = vina.matches("^[a-zA-Z0-9]*$");
        isvinnNumeric = vinn.matches("^[0-9]*$");
        isNumeric = speed.matches("^[0-9]*$");
        
 	   if(isvinaalphaNumeric && isNumeric && isvinnNumeric ) {
            if(Integer.parseInt(speed)>100 ){
                alert = 'y';
                verify = 'y';
                System.out.println("produced message  "+vin+verify+speed+alert+dateTime);
                create(new Vinspeed(vin+verify+speed+alert+dateTime));
//                producer.publishToTopic(vin+verify+speed+alert+dateTime);
            }
            else{
                verify = 'y';
               create(new Vinspeed(vin+verify+speed+alert+dateTime));
               System.out.println("produced message  "+vin+verify+speed+alert+dateTime);
//                producer.publishToTopic(vin+verify+speed+alert+dateTime);
            }
 		  return 1;
 	   }
		else{
			if(Integer.parseInt(speed)>100){
                alert = 'y';
                verify = 'n';
                create(new Vinspeed(vin+verify+speed+alert+dateTime));
                System.out.println("produced message  "+vin+verify+speed+alert+dateTime);
//                producer.publishToTopic(vin+verify+speed+alert+dateTime);
            }
			else{
                
                verify = 'n';
				alert ='n';
				create(new Vinspeed(vin+verify+speed+alert+dateTime));
				System.out.println("produced message  "+vin+verify+speed+alert+dateTime);
//                producer.publishToTopic(vin+verify+speed+alert+dateTime);
            }
		}
		return 0;
		
		//String sample = "a1sderfghju147896325";
	    //String [] splitString = sample.split();
			
		
		
	}

	@PostMapping(value="/manual")
    public String postBody(@RequestBody UserDetailsRequestData requestdetails )
	{
//		auth();
		
		String vin=requestdetails.getVin();
	    String speed=requestdetails.getSpeed();
        boolean isvinaalphaNumeric;
        boolean isvinnNumeric;
 	    boolean isNumeric;
        Date date=new Date();
        Timestamp ts=new Timestamp(date.getTime());
        DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String strDate=dateFormat.format(ts);
        char verify = 'n';
        char alert = 'n';
        int sp=Integer.parseInt(speed);

        if(vin.isEmpty() || speed.isEmpty()){
            return "Data is empty";
        }
        if(vin.length()!=17 || speed.length()!= 3 || sp<0){
            return "Data is not appropriate";
        }
        String vina = vin.substring(0,10);
        String vinn = vin.substring(11,16);

        isvinaalphaNumeric = vina.matches("^[a-zA-Z0-9]*$");
        isvinnNumeric = vinn.matches("^[0-9]*$");
        isNumeric = speed.matches("^[0-9]*$");
 	   
 	   if(isvinaalphaNumeric && isNumeric && isvinnNumeric) {
            if(Integer.parseInt(speed)>100){
                alert = 'y';
                verify = 'y';
                create(new Vinspeed(vin+verify+speed+alert+strDate));
                System.out.println("produced message  "+vin+verify+speed+alert+strDate);
//                producer.publishToTopic(vin+verify+speed+alert+strDate);
            }
            else{
                verify = 'y';
             create(new Vinspeed(vin+verify+speed+alert+strDate));
             System.out.println("produced message  "+vin+verify+speed+alert+strDate);
//                producer.publishToTopic(vin+verify+speed+alert+strDate);
            }
 		  return "Data is acceptable";
 	   }
		else{
			if(Integer.parseInt(speed)>100){
                alert = 'y';
                verify = 'n';
               create(new Vinspeed(vin+verify+speed+alert+strDate));
               System.out.println("produced message  "+vin+verify+speed+alert+strDate);
//                producer.publishToTopic(vin+verify+speed+alert+strDate);
            }
			else{
                verify = 'n';
				alert ='n';
				create(new Vinspeed(vin+verify+speed+alert+strDate));
				System.out.println("produced message  "+vin+verify+speed+alert+strDate);
//                producer.publishToTopic(vin+verify+speed+alert+strDate);
            }
		}
		return "Data is acceptable";
    }
}
