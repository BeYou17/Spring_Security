package com.dedsec995.M2.repo;




import java.util.List;

import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.dedsec995.M2.model.UserEntity;





public interface UserRepository extends CassandraRepository<UserEntity, String> {

 @Query(value="SELECT * FROM User WHERE mail=?0 ALLOW FILTERING")
  public UserEntity findByMail(String mail);

//	List<org.springframework.security.core.userdetails.User> findByUsername(String userName);

//	org.springframework.security.core.userdetails.User findByUsername(String userName);

	

//	org.springframework.security.core.userdetails.User findByUsername(String userName);
    //username , it will return the user of given username
//    public User findByUsername1(String username);
//	@AllowFiltering
//    public User findByUsername(String userName);

}
