package com.dedsec995.M2.controller;



public class UserDetailsRequestData {
	   private String vin;
		private String speed;
		
		@Override
		public String toString() {
			return "UserDetailsRequestData [vin=" + vin + ", speed=" + speed + "]";
		}
		public UserDetailsRequestData(String vin, String speed) {
			super();
			this.vin = vin;
			this.speed = speed;
		}
		public String getVin() {
			return vin;
		}
		public void setVin(String vin) {
			this.vin = vin;
		}
		public String getSpeed() {
			return speed;
		}
		public void setSpeed(String speed) {
			this.speed = speed;
		}
		
	
	}
