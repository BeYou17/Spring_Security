package com.reg.user.save.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.reg.user.save.model.User;
import com.reg.user.save.repo.UserRepository;



@RestController
@CrossOrigin(origins = "http://127.0.0.1:5501")
public class NoAuthController {
	@Autowired
    private UserRepository userRepository;
	@GetMapping("/get/{mail}")
	public  String findByMail(@PathVariable String mail){
		User data= userRepository.findByMail(mail);
		String name=data.getUsername();
		
		
		return name;
	}

	@PostMapping("/post")
	public @ResponseBody ResponseEntity<String> post() {
		
	    return new ResponseEntity<String>("POST Response hi hello i am fine you ???", HttpStatus.OK);
	}
	

	@PostMapping("/reg")
	public void saveUser(@RequestBody User user) {
	 String mail=user.getMail();
 String username=user.getUsername();
//	   String password=user.getPassword();
//	   String rol=user.getRol();
System.out.println(mail.contains("@tataelxsi"));
//	   user.add(new User(mail,username,password,rol));
		userRepository.save(user);
		
	}
	
	
	
}
