package com.reg.user.save;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserSaveApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserSaveApplication.class, args);
	}

}
