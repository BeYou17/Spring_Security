package com.dedsec995.M1.controller;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.dedsec995.M1.M1Application;
import com.dedsec995.M1.RandomString;
//import com.dedsec995.M1.config.JwtAuthenticationFilter;
import com.dedsec995.M1.model.Vinspeed;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;

import net.minidev.json.JSONObject;


//import com.dedsec995.M1.service.Producer;



@RestController
@CrossOrigin(origins = "http://127.0.0.1:5501")
public class KafkaController {
	
//	@Autowired 
//	Producer producer;
	@Autowired 
	M1Application m1;
	
	@Autowired
	RestTemplate restTemplate;

//	@Autowired
//	JwtAuthenticationFilter jr;

	public static String token;
	
//	
	
	   @RequestMapping("/secured")
	    public String secured(){
	        System.out.println("Inside secured()");
	        return "Hello user !!! : " + new Date();
	    }
	   
	   public void token(String tkn) {
		   System.out.println(tkn);
		   token=tkn;
	   }
	   
	   public String auth() {
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>(createHeaders("sunil", "123"));
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>();
		//body.add("username","sunil");
		//body.add("password","abde");

		String payload="{\"username\":\"sunil\",\"password\":\"abde\"}";
        

		//body.add("sunil","abde");
//		    System.out.println(body);
//		    System.out.println(createHeaders("dsaugi", "kmlcnpasqwds"));
			HttpHeaders headers=new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

//			   headers.set("Authorization", "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzdW5pbCIsImV4cCI6MTY0MDM4NTgyMiwiaWF0IjoxNjQwMzY3ODIyfQ.6GdzTALoIbU2BySPiU9nO6ZfD3CKosFHNq9k5o3cBzZ61IPrs6p5U9VTFdacNq4Sm3hajIPkhhxtmb2rCnpznA");
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<String> entity=new HttpEntity<String>(payload,headers);
		// HttpEntity<MultiValueMap<String,String>> entity=new HttpEntity<MultiValueMap<String,String>>(body,headers);
			ResponseEntity<String> response=restTemplate.exchange("http://M2-SERVICE/token",HttpMethod.POST,entity,String.class);
//			System.out.println(response.getBody());
//			if(response.getStatusCodeValue()==201) {
//				System.out.println("Succes");
			if(response!=null && response.getStatusCode().equals(HttpStatus.OK)) {

//			   response.getBody().valueOf(token);
			
               token=response.getBody();
//				 System.out.println(response.getBody());
				return "SUCCESS!";
			}
//				
//			}
		    return "wrong credentials";
			
		}
	  
	   public String create(Vinspeed vinspeed) {
		
		   
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>(createHeaders("sunil", "123"));
//		    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>();
		// body.add("sunil", "pass");
//		    System.out.println(body);
//		    System.out.println(createHeaders("dsaugi", "kmlcnpasqwds"));
			 HttpHeaders headers=new HttpHeaders();
		     headers.set("Authorization", "Bearer "+token);
//			 System.out.println(token);
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//			HttpEntity<Vinspeed> entity=new HttpEntity<Vinspeed>(vinspeed,createHeaders("sunil", "pass"));
		  HttpEntity<Vinspeed> entity1=new HttpEntity<Vinspeed>(vinspeed,headers);
			ResponseEntity<String> response1=restTemplate.exchange("http://M2-SERVICE/vinspeed",HttpMethod.POST,entity1,String.class);
//			System.out.println(response.getBody());
//			if(response.getStatusCodeValue()==201) {
//				System.out.println("Succes");
//				
//			}
		    return response1.getBody();
			
		}

	@PostMapping(value="/pro")
    public String postBody(@RequestBody UserDetailsRequestData requestdetails) {
		
//		auth();
		
		
		Integer vin = requestdetails.getVinCount();
		Integer freq = requestdetails.getDelay();
      String same=requestdetails.getDifferent();
 System.out.println(vin);
    System.out.println(freq);
        int secondsToSleep = freq;
	    int i;

		boolean isEqual1 =  same.equals("Yes");
		boolean isEqual2 = same.equals("Y");
		boolean isEqual3 =  same.equals("yes");
		boolean isEqual4 = same.equals("y");
		if(same.isEmpty()){
			try{
				for(i=0;i<vin;i++){
				String result1 = RandomString.getVinSpeed(20);
				Date date=new Date();
				Timestamp ts=new Timestamp(date.getTime());
				DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String strDate=dateFormat.format(ts);
					System.out.println(result1+strDate);
//				producer.publishToTopic(result1+strDate);	
					create(new Vinspeed(result1+strDate));
				Thread.sleep(secondsToSleep * 1000);
				}
			}catch(InterruptedException ie){
				Thread.currentThread().interrupt();
			}
		}
		else if(isEqual1 || isEqual2 || isEqual3 || isEqual4){
			String vinn = RandomString.getVin();
			try{
				for(i=0;i<vin;i++){
					Date date=new Date();
					Timestamp ts=new Timestamp(date.getTime());
					DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String strDate=dateFormat.format(ts);	
					String speeed = RandomString.getSpeed();
					System.out.println(vinn+speeed+strDate);
//					producer.publishToTopic(vinn+speeed+strDate);
					create(new Vinspeed(vinn+speeed+strDate));
					Thread.sleep(secondsToSleep * 1000);
				}
			}catch(InterruptedException ie){
				Thread.currentThread().interrupt();
			}
		}
		else{
			try{
				for(i=0;i<vin;i++){
					String result1 = RandomString.getVinSpeed(20);
					Date date=new Date();
					Timestamp ts=new Timestamp(date.getTime());
					DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String strDate=dateFormat.format(ts);
					System.out.println(result1+strDate);
//					producer.publishToTopic(result1+strDate);
					create(new Vinspeed(result1+strDate));
					Thread.sleep(secondsToSleep * 1000);
				}
			}catch(InterruptedException ie){
				Thread.currentThread().interrupt();
			}
		
//		System.out.println(token);
		}
		return "data accepted";
		
    }
}
