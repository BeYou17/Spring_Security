package com.dedsec995.M1.model;

public class Vinspeed {
	private String vinspeed;

	@Override
	public String toString() {
		return "Vinspeed [vinspeed=" + vinspeed + ", getVinspeed()=" + getVinspeed() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	public Vinspeed() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vinspeed(String vinspeed) {
		super();
		this.vinspeed = vinspeed;
	}

	public String getVinspeed() {
		return vinspeed;
	}

	public void setVinspeed(String vinspeed) {
		this.vinspeed = vinspeed;
	}

}
