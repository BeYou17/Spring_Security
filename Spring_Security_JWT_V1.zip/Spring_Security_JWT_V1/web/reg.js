class App {
  constructor() {
    const user = document.querySelector("#name");
    const pass = document.querySelector("#pass");
    const rol = document.querySelector("#role");
    const mail = document.querySelector("#mail");

    let user = document.getElementById("name");
    let pass = document.getElementById("pass");
    let rol = document.getElementById("role");
    let mail = document.getElementById("mail");
    const form = document.querySelector("form");
    console.log(mail.value, user.value, pass.value);

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      console.log(mail, user, pass);
      this.credDetails(mail.value, user.value, pass.value);
    });
  }
  credDetails = (userMail, userName, passWord) => {
    if (
      userName.length === 0 ||
      passWord.length === 0 ||
      userMail.length === 0
    ) {
      alert("UserName and Password Cannot be Empty");
      return;
    }
    const data = {
      mail: userMail,
      username: userName,
      password: passWord,
    };

    let options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        // "Access-Control-Allow-Origin": "http://localhost:8999",
      },
      body: JSON.stringify(data),
      // mode: "no-cors",
    };
    fetch("http://localhost:8999/reg", options)
      .then(function (response) {
        console.log(response);
        return response.status;
      })
      .then(function (status) {
        console.log(status);
        if (status === 200) {
          alert("success");
          window.location.replace("login.html");
          console.log("success");
        }
      })
      .then((res) => {
        console.log(res?.token);
        if (res.token) {
          localStorage.setItem("AccessToken", res.token);
          window.location.replace("index.html");
        } else {
          alert("unsuccess");
          console.log("unsuccess");
        }
      });
  };
}

const app = new App();
