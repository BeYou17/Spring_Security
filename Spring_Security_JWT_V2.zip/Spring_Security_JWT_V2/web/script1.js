// let vin = document.getElementById("vin");
// let speed = document.getElementById("speed");

// let myFormEl = document.getElementById("myForm");

// myFormEl.addEventListener("submit", (e) => {
//   e.preventDefault();
//   let formData = {
//     vin: vin.value,
//     speed: speed.value,
//   };
//   console.log(formData);
//   const submitFormData = (formData) => {
//     console.log(formData);
//     let options = {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//         Accept: "application/json",
//         Authorization:
//           "Bearer eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbiIsImF1dCI6IkFQUExJQ0FUSU9OIiwiYXVkIjoiOGJtV0lFdURWUDV0Rm9rdE9vT21LNU1RcU1JYSIsIm5iZiI6MTYzNjYyMjUyNywiYXpwIjoiOGJtV0lFdURWUDV0Rm9rdE9vT21LNU1RcU1JYSIsInNjb3BlIjoiZGVmYXVsdCIsImlzcyI6Imh0dHBzOlwvXC9sb2NhbGhvc3Q6OTQ0M1wvb2F1dGgyXC90b2tlbiIsImV4cCI6MTYzNjYyNjEyNywiaWF0IjoxNjM2NjIyNTI3LCJqdGkiOiI1OTU0ZjE1NC1hNGJjLTRhNjAtOTJiNS0wMDA5ZDE1NTI2MDAifQ.iXjO9O4vwAr5Bd1WToxJEQr6D5Dd_JUFUU9YNOlL1_F-pxeqJaJR5CBX9tv4qDvF1U95Wj4Htz34_IXa1EkKroeewHy2yg2Xak9wPhRyBkBHa2uVhu1wFHqHTMbBQ8SNtWwzBScFOyVJ_uqltO1nxz1mfPdAbKVby300pWp46pMKWv58kgW_KlV5btobVtgporVkFPIiH4Ffy0Xm4fSqi_sxYASQni6Bb5AVC2ZRIBaN13pM6XnaS53RJ9Z7KBzEQflC4PPNdw2DBLKq6BUt9k95uO-TnQTmJDdg2Dzmz2C5bW9nXte5WNWP8vKvfYavlftZvcCJwTWGyVt4_m0owQ",
//       },
//       body: JSON.stringify(formData),
//     };
//     let url = "https://localhost:8243/post/1.0";
//     fetch(url, options)
//       .then(function (response) {
//         return response.json();
//       })
//       .then(function (jsonData) {
//         console.log(jsonData);
//         if (jsonData.code === 422) {
//           if (jsonData.data[0].message === "has already been taken") {
//             emailErrMsgEl.textContent = "Email Already Exists";
//           }
//         }
//       });
//   };
//   submitFormData(formData);
// });

let vinNo = document.getElementById("vin");
let freq = document.getElementById("freq");
let same = document.getElementById("same");

function checking() {
  let data = {
    vinCount: vinNo.value,
    delay: freq.value,
    different: same.value,
  };

  console.log(data);
  let vinNoCheck = vinNo.value;
  let freqCheck = freq.value;
  let sameCheck = same.value;
  same.value ? (same.value = sameCheck) : (same.value = "y");
  console.log(typeof vinNoCheck);
  console.log(freqCheck);
  //   let sp =+speed.value;
  //   if (vinNo.value == "" || speed.value == "") {
  //     alert("empty");
  //     return "Data is empty";
  //   }

  //   console.log(sp);
  //   if (vin.value.length != 17 || speed.value.length != 3 || sp < 0) {
  //     alert("not appropriate");
  //     return "Data is not of appropriate";
  //   }

  if (+vinNoCheck <= 0 && vinNoCheck !== +vinNoCheck) {
    alert("invalid entry");
    console.log(vinNoCheck);
    return "invalid entry";
  }
  if (+freqCheck <= 0 && freqCheck !== +freqCheck) {
    alert("invalid entry");
    console.log(freqCheck);
    return "invalid entry";
  }
  if (
    sameCheck !== "y" &&
    sameCheck !== "Y" &&
    sameCheck !== "n" &&
    sameCheck !== "N" &&
    sameCheck !== ""
  ) {
    alert("invalid entry");
    return "invalid entry";
  }
  if (sameCheck == "") {
    same.value = "y";
  }
  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${localStorage.getItem("AccessToken")}`,
    },
    body: JSON.stringify(data),
  };
  console.log(data);
  fetch("http://localhost:8999/pro", options)
    .then(function (response) {
      console.log(response.body);
      return response.status;
    })
    .then(function (status) {
      console.log(status);
      if (status == 200) {
        alert("success");
        console.log("success");
      } else if (status === 401) {
        window.location.replace("login.html");
      } else {
        alert("unsuccess");
        console.log("unsuccess");
      }
    });
  //
}

const logout = () => {
  localStorage.removeItem("AccessToken");
  window.location.replace("login.html");
};
