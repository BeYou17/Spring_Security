class App {
  constructor() {
    const user = document.querySelector("#user");
    const pass = document.querySelector("#pass");
    const form = document.querySelector("form");

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      console.log(user.value, pass.value);
      this.credDetails(user.value, pass.value);
    });
  }
  credDetails = (userName, passWord) => {
    if (userName.length === 0 || passWord.length === 0) {
      alert("UserName and Password Cannot be Empty");
      return;
    }
    const data = {
      useraname: userName,
      password: passWord,
    };

    let options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        // "Access-Control-Allow-Origin": "http://localhost:8999",
      },
      body: JSON.stringify(data),
      // mode: "no-cors",
    };
    fetch("http://localhost:8999/token", options)
      .then(function (response) {
        return response.json();
      })
      .then((res) => {
        console.log(res?.token);
        if (res.token) {
          localStorage.setItem("AccessToken", res.token);
          window.location.replace("index.html");
        } else {
          alert("unsuccess");
          console.log("unsuccess");
        }
      });
  };
}

const app = new App();
