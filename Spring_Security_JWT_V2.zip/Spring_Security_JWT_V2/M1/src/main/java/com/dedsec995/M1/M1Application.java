 package com.dedsec995.M1;

import java.nio.charset.Charset;
import java.util.Arrays;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.dedsec995.M1.model.Vinspeed;

//scanBasePackages={"com.dedsec995.M1.model"}
@SpringBootApplication()
@EnableDiscoveryClient
@EnableEurekaClient
public class M1Application {


	public static void main(String[] args) {
		SpringApplication.run(M1Application.class, args);
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
		
	}

@Autowired
RestTemplate restTemplate;


//HttpHeaders createHeaders(String username, String password){
//	   return new HttpHeaders() {{
//	         String auth = username + ":" + password;
//	         byte[] encodedAuth = Base64.encodeBase64( 
//	            auth.getBytes(Charset.forName("US-ASCII")) );
//	         String authHeader = "Basic " + new String( encodedAuth );
//	         set( "Authorization", authHeader );
//	      }};
//	      
//	}

//public String create(Vinspeed vinspeed) {
////    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>(createHeaders("sunil", "123"));
////    MultiValueMap<String,String> body=new LinkedMultiValueMap<String, String>();
//// body.add("sunil", "pass");
////    System.out.println(body);
////    System.out.println(createHeaders("dsaugi", "kmlcnpasqwds"));
//	HttpHeaders headers=new HttpHeaders();
//
//	   headers.set("Authorization", "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJzdW5pbCIsImV4cCI6MTY0MDM4NTgyMiwiaWF0IjoxNjQwMzY3ODIyfQ.6GdzTALoIbU2BySPiU9nO6ZfD3CKosFHNq9k5o3cBzZ61IPrs6p5U9VTFdacNq4Sm3hajIPkhhxtmb2rCnpznA");
////	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
////	HttpEntity<Vinspeed> entity=new HttpEntity<Vinspeed>(vinspeed,createHeaders("sunil", "pass"));
// HttpEntity<Vinspeed> entity=new HttpEntity<Vinspeed>(vinspeed,headers);
//	ResponseEntity<String> response=restTemplate.exchange("http://localhost:8881/vinspeed",HttpMethod.POST,entity,String.class);
////	System.out.println(response.getBody());
////	if(response.getStatusCodeValue()==201) {
////		System.out.println("Succes");
////		
////	}
//    return response.getBody();
//	
//}

}
