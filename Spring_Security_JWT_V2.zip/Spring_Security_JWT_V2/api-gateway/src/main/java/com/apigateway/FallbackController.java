//package com.apigateway;
//
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class FallbackController {
//	
//	@GetMapping("/m1fallback")
//	public String firstServceFallback() {
//		return "M1 is down";
//		
//	}
//	
//	@GetMapping("/m2fallback")
//	public String secondServceFallback() {
//		return "M2 is down";
//		
//	}
//	
//	@GetMapping("/authfallback")
//	public String authServceFallback() {
//		return "auth is down";
//		
//	}
//
//}
