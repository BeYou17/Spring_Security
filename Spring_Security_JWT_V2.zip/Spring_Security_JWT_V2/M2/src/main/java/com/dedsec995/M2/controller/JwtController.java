//package com.dedsec995.M2.controller;
//
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.web.bind.annotation.*;
//
//import com.dedsec995.M2.model.JwtRequest;
//import com.dedsec995.M2.model.JwtResponse;
//import com.dedsec995.M2.service.CustomUserDetailsService;
//import com.dedsec995.M2.util.JwtUtil;
//
//
//
//
//@RestController
//@CrossOrigin
//public class JwtController {
//
//    @Autowired
//    private AuthenticationManager authenticationManager;
//
//
//    @Autowired
//    private CustomUserDetailsService customUserDetailsService;
//
//    @Autowired
//    private JwtUtil jwtUtil;
//    
//    @Autowired
//    kafkaController k1;
//
//    @RequestMapping(value = "/token", method = RequestMethod.POST)
//    public String generateToken(@RequestBody JwtRequest jwtRequest) throws Exception {
////    	 k1.auth();
//        System.out.println("Inside Controller");
////        System.out.println(jwtRequest);
//        try {
//
//            this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(), jwtRequest.getPassword()));
//
//
//        } catch (UsernameNotFoundException e) {
//            e.printStackTrace();
//            throw new Exception("djs Credentials");
//        }catch (BadCredentialsException e)
//        {
//            e.printStackTrace();
//            throw new Exception("Bad Credentials");
//        }
//
//
//        //fine area..
//        UserDetails userDetails = this.customUserDetailsService.loadUserByUsername(jwtRequest.getUsername());
//
//        String token = this.jwtUtil.generateToken(userDetails);
//        System.out.println("JWT " + token);
//
//        //{"token":"value"}
//
//        return token;
//
//    }
//}
