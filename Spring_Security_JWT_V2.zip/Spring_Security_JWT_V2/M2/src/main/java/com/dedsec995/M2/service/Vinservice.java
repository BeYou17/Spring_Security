//package com.dedsec995.M2.service;
//
//import com.dedsec995.M2.model.Vinspeed;
//
//public interface Vinservice {
//
//   public abstract Vinspeed create(Vinspeed vinspeed);
//   
//   }
