package com.dedsec995.M2.model;



import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;
@Table("user")
public class UserEntity {

	@PrimaryKey
    private String mail;
    private String username;
    private String password;
    private String rol;
    
	public UserEntity(String mail, String username, String password, String rol) {
		super();
		this.mail = mail;
		this.username = username;
		this.password = password;
		this.rol = rol;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRol() {
		return rol;
	}
	public void setRol(String rol) {
		this.rol = rol;
	}
    
  


    //more properties as your project requirements


   
  
    }

