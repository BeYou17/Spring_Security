//package com.dedsec995.M2.service;
//
//
//@Service
//public class Vinimpl implements Vinservice {
//
//}
