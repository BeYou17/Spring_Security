package com.dedsec995.M3.service;



//import com.jwt.model.CustomUserDetails;
//import com.jwt.model.User;
//import com.jwt.repo.UserRepository;

import org.springframework.security.core.userdetails.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.dedsec995.M3.model.UserEntity;
import com.dedsec995.M3.repository.EntityRepo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private EntityRepo userRepository;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

    	UserEntity user = userRepository.findByMail(userName);
//      final User user = this.userRepository.findByUsername(userName);
//
//      if (user == null) {
//          throw new UsernameNotFoundException("User not found !!");
//      } else {
//          return new CustomUserDetails(user);
//      }


//      user database `

//      if (userName.equals("sunil")) {
//          return new  User("sunil", "abde", new ArrayList<>());
//      } else {
//          throw new UsernameNotFoundException("User not found !!");
//      }
  	List<SimpleGrantedAuthority> roles = null;
		if(userName.equals(user.getMail()))
		{
			roles=Arrays.asList(new SimpleGrantedAuthority(user.getRol()));
			return new User(user.getMail(),user.getPassword(),roles);
		}
//		if(userName.equals("user"))
//		{
//			roles=Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
//			return new User("user","virat",roles);
//		}
//		if(userName.equals("sunil"))
//		{
//			roles=Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
//			return new User("sunil","123",roles);
//		}
		throw new UsernameNotFoundException("User not found with the name "+ userName);

    }
}
