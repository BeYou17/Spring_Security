package com.dedsec995.M3.repository;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import com.dedsec995.M3.model.UserEntity;


public interface EntityRepo extends CassandraRepository<UserEntity, String> {

	 @Query(value="SELECT * FROM User WHERE mail=?0 ALLOW FILTERING")
	  public UserEntity findByMail(String mail);
}
